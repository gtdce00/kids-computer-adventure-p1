﻿ห้องเกมการศึกษา ครูคอม — วิธีติดตั้ง
1) คลิกขวาที่ไฟล์ zip นี้ > Extract All (แตกไฟล์ทั้งหมด)
2) ดับเบิลคลิก GameRoom-Setup.exe
3) กด ถัดไป > เสร็จสิ้น  จะได้ไอคอน "ห้องเกมการศึกษา ครูคอม" บน Desktop
ถ้าขึ้น "Windows protected your PC" ให้กด More info > Run anyway
