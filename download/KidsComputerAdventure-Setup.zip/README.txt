﻿KIDS COMPUTER ADVENTURE ป.1 — วิธีติดตั้ง
1) คลิกขวาที่ไฟล์ zip นี้ > Extract All (แตกไฟล์ทั้งหมด)
2) ดับเบิลคลิก KidsComputerAdventure-Setup.exe
3) กด ถัดไป > เสร็จสิ้น  จะได้ไอคอนบน Desktop
ถ้าขึ้น "Windows protected your PC" ให้กด More info > Run anyway
